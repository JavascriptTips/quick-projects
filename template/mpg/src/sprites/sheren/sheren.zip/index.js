var mySpriteFn = require('./sprite.js');
var mySprite = mySpriteFn();

mySprite.render = function () {
}

module.exports = mySprite;